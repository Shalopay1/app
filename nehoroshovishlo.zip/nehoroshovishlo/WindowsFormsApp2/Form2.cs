﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        private const string FileName = "authentication.txt";
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string _login = tbLogin.Text;
            string _pass = tbPass.Text;

            using ( StreamWriter file = new StreamWriter(FileName, true,Encoding.Default))
            {
                file.WriteLine("{0};{1};0", _login, _pass);
            }

            Close();
        }
    }
}
