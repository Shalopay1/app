﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApp2;

namespace WindowsFormsApp94
{
    public partial class Form1 : Form
    {
        private const string FileName = "authentication.txt";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Authentication();
        }

        private void Authentication()
        {
            if (!File.Exists(FileName))
            {
                MessageBox.Show("Зарегестрируйтесь");

                using (StreamWriter Write = new StreamWriter(FileName, false, Encoding.Default))
                {
                    Write.Write("admin;admin;1");
                }

                MessageBox.Show("Файл создан.");
            }
            else
            {
                if (textBox1.Text != "" && textBox2.Text != "")
                {
                    CheckAccessRight();
                }
                else
                {
                    MessageBox.Show("Необходимо заполнить все поля авторизации.");
                }
            }
        }

        private void CheckAccessRight()
        {
            Authority NewAuthority = new Authority(FileName, textBox1.Text, textBox2.Text);

            var X = NewAuthority.IncorrectInput();

            if (X.Count() != 0)
            {
                foreach (var Row in X)
                {
                    if (Row.Role == 1)
                    {
                        MessageBox.Show($"Вход под админом ({Row.User}).");
                    }
                    else
                    {
                        MessageBox.Show($"Вход под пользователем ({Row.User}).");
                    }
                }
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль. Повторите вход.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();

        }
    }

    public class Authority
    {
        private readonly string _FileName;

        private readonly string _Login;

        private readonly string _Password;

        public Authority(string FileName, string Login, string Password)
        {
            this._FileName = FileName;

            this._Login = Login;

            this._Password = Password;
        }

        public List<Authentication> IncorrectInput()
        {
            string[] Data = File.ReadAllLines(_FileName);

            List<Authentication> Lst = new List<Authentication>();

            for (int i = 0; i < Data.Length; i++)
            {
                Authentication Auth = new Authentication();

                string[] Row = Data[i].Split(';');

                Auth.User = Row[0];

                Auth.Password = Row[1];

                Auth.Role = Convert.ToInt32(Row[2]);

                Lst.Add(Auth);
            }

            return Lst.Where(w => w.User == _Login && w.Password == _Password).ToList();
        }
    }

    public struct Authentication
    {
        public string User { get; set; }

        public string Password { get; set; }

        public int Role { get; set; }
    }
}